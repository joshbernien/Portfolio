create database instgram;
use instagram

CREATE TABLE users (
    id INTEGER AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

source Instagram/instagram_photos.sql;

source Instagram/instagram_comments.sql;

source Instagram/instagram_likes.sql;

source Instagram/instagram_followers.sql;

source Instagram/instagram_hashtags.sql;

