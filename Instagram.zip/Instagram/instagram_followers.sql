create table followers (
    follower_id integer not null,
    followee_id integer not null,
    created_at timestamp DEFAULT now(),
    foreign key (follower_id) REFERENCES users(id),
    foreign key (followee_id) REFERENCES users(id),
    primary key (follower_id, followee_id)
);