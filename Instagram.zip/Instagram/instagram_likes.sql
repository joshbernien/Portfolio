create table likes (
    user_id integer not null,
    photo_id integer not null,
    created_at timestamp default now(),
    FOREIGN key (user_id) REFERENCES users(id),
    foreign key (photo_id) REFERENCES photos(id),
    PRIMARY key(user_id, photo_id)
);    