create table comments (
    id integer AUTO_INCREMENT PRIMARY key,
    comment_text varchar(255) not null,
    user_id integer not null,
    photo_id integer not null,
    created_at timestamp default now(),
    FOREIGN key(user_id) REFERENCES users(id),
    FOREIGN key(photo_id) REFERENCES photos(id)
);