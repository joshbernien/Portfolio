create table photos (
    id integer AUTO_INCREMENT primary key,
    image_url varchar(255) not null,
    user_id integer not null,
    created_at timestamp DEFAULT now(),
    FOREIGN key(user_id) REFERENCES users(id)
);
